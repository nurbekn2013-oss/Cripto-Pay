# CryptoPay — 5-bosqich: Backend va xavfsiz kirish

Bu loyiha demo backend poydevori. U ro'yxatdan o'tish, kirish, profil, administrator rolini tekshirish va TOTP 2FA boshlang'ich funksiyalarini beradi.

**Muhim:** bu real kripto-birja emas. Unda real savdo, depozit, yechib olish, kripto hamyon, private key saqlash yoki mijoz mablag'lari yo'q. Real pul bilan ishga tushirishdan oldin tegishli ruxsatlar, KYC/AML, yuridik xulosa, xavfsizlik auditi, monitoring, zaxira nusxalari va professional infratuzilma talab etiladi.

## Kerak bo'ladi
- Node.js 20 yoki yangiroq
- PostgreSQL 14 yoki yangiroq

## 1. Ma'lumotlar bazasi
PostgreSQL'da `cryptopay` nomli baza va foydalanuvchi yarating. So'ng quyidagini bajaring:

```bash
psql "postgresql://cryptopay_user:PAROL@localhost:5432/cryptopay" -f sql/schema.sql
```

Yoki `sql/schema.sql` faylini pgAdmin Query Tool orqali ishga tushiring.

## 2. Muhit sozlamalari
`.env.example` faylidan `.env` nusxa oling. `DATABASE_URL` ni o'zingizning PostgreSQL ma'lumotlaringiz bilan to'ldiring.

Maxfiy kalitlarni yaratish:
```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```
Birinchi natijani `JWT_SECRET` ga qo'ying. Ikkinchi natija 64 hex belgidan iborat bo'ladi — `TOTP_ENCRYPTION_KEY` ga qo'ying. Bu kalitlarni hech kimga yubormang va repozitoriyga joylamang.

## 3. Ishga tushirish
```bash
npm install
npm run dev
```
Tekshirish: `http://localhost:4000/health`

## API yo'llari
- `POST /api/auth/register` — `{ "email": "user@example.com", "password": "kamida12belgi" }`
- `POST /api/auth/login` — email va parol; 2FA yoqilgan bo'lsa `code` ham kerak.
- `GET /api/auth/me` — `Authorization: Bearer TOKEN`
- `POST /api/auth/2fa/setup` — login tokeni bilan TOTP secret yaratadi.
- `POST /api/auth/2fa/enable` — `{ "code": "123456" }` bilan 2FA ni yoqadi.
- `GET /api/auth/admin/users` — faqat `admin` roli uchun.

## Administratorni tayinlash (faqat o'zingizning lokal demo bazangizda)
Avval oddiy foydalanuvchi sifatida ro'yxatdan o'ting, keyin pgAdmin yoki psql orqali:
```sql
UPDATE users SET role='admin' WHERE email='sizning-emailingiz@example.com';
```
Rol o'zgargach, qayta login qiling — yangi token yangi rolni oladi. Internetdagi ochiq serverda buni nazoratsiz bajarmang.

## Eslatma va keyingi ishlar
- Access token 15 daqiqada tugaydi; bu starter loyihada refresh-token mexanizmi yo'q.
- Frontend tokenini xavfsiz saqlash va production cookie/session strategiyasini alohida ishlab chiqish kerak.
- 2FA setup javobidagi secret faqat bir marta ko'rsatilishi kerak; demo uchun endpoint qaytaradi. Production'da QR/secret ko'rsatish jarayoni va qayta tiklash siyosati mustahkamlanishi shart.
- Email tasdiqlash, parolni tiklash, audit log, CSRF (cookie ishlatilsa), monitoring, backup, WAF, secrets manager va mustaqil penetration test hali qo'shilmagan.
- `TOTP_ENCRYPTION_KEY` yo'qolsa, saqlangan 2FA secretlarni ochib bo'lmaydi. Uni xavfsiz backup qiling.
