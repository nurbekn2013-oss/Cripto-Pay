const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const { router: authRouter } = require("./auth");
const { port, corsOrigin, nodeEnv } = require("./config");
const db = require("./db");

const app = express();
app.disable("x-powered-by");
app.use(helmet());
app.use(cors({ origin: corsOrigin.split(",").map(s => s.trim()), methods: ["GET", "POST"], allowedHeaders: ["Content-Type", "Authorization"] }));
app.use(express.json({ limit: "20kb" }));

app.use("/api", rateLimit({ windowMs: 15 * 60 * 1000, limit: 120, standardHeaders: "draft-7", legacyHeaders: false }));
app.use("/api/auth", rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: "draft-7", legacyHeaders: false }));
app.get("/health", async (_req, res) => {
  try {
    await db.query("SELECT 1");
    res.json({ ok: true, service: "CryptoPay API", database: "connected", mode: "demo-foundation" });
  } catch {
    res.status(503).json({ ok: false, database: "unavailable" });
  }
});
app.use("/api/auth", authRouter);
app.use((req, res) => res.status(404).json({ error: "Endpoint topilmadi" }));
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({
    error: nodeEnv === "production" ? "Ichki server xatosi" : err.message
  });
});

app.listen(port, () => console.log(`CryptoPay API http://localhost:${port}`));
