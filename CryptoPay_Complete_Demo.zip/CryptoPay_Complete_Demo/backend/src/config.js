require("dotenv").config();

const required = ["DATABASE_URL", "JWT_SECRET", "TOTP_ENCRYPTION_KEY"];
for (const key of required) {
  if (!process.env[key]) throw new Error(`.env ichida ${key} ko'rsatilmagan`);
}
if (process.env.JWT_SECRET.length < 32) {
  throw new Error("JWT_SECRET kamida 32 belgidan iborat bo'lishi kerak");
}
if (!/^[0-9a-fA-F]{64}$/.test(process.env.TOTP_ENCRYPTION_KEY)) {
  throw new Error("TOTP_ENCRYPTION_KEY 64 ta hex belgidan iborat bo'lishi kerak");
}

module.exports = {
  port: Number(process.env.PORT || 4000),
  databaseUrl: process.env.DATABASE_URL,
  jwtSecret: process.env.JWT_SECRET,
  totpKey: Buffer.from(process.env.TOTP_ENCRYPTION_KEY, "hex"),
  corsOrigin: process.env.CORS_ORIGIN || "http://localhost:5173",
  nodeEnv: process.env.NODE_ENV || "development"
};
