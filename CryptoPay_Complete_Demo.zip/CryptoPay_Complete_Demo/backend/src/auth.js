const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const speakeasy = require("speakeasy");
const { z } = require("zod");
const db = require("./db");
const { jwtSecret } = require("./config");
const { encryptSecret, decryptSecret } = require("./security");

const router = express.Router();
const registerSchema = z.object({
  email: z.string().email().max(254).transform(v => v.toLowerCase().trim()),
  password: z.string().min(12).max(128)
});
const loginSchema = registerSchema.extend({
  code: z.string().regex(/^\d{6}$/).optional()
});

function makeToken(user) {
  return jwt.sign(
    { sub: String(user.id), role: user.role },
    jwtSecret,
    { expiresIn: "15m", issuer: "cryptopay-api", audience: "cryptopay-client" }
  );
}

async function authRequired(req, res, next) {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : "";
    if (!token) return res.status(401).json({ error: "Kirish talab qilinadi" });
    req.auth = jwt.verify(token, jwtSecret, {
      issuer: "cryptopay-api",
      audience: "cryptopay-client"
    });
    next();
  } catch {
    return res.status(401).json({ error: "Token yaroqsiz yoki muddati tugagan" });
  }
}

function adminRequired(req, res, next) {
  if (req.auth?.role !== "admin") {
    return res.status(403).json({ error: "Faqat administrator uchun" });
  }
  next();
}

router.post("/register", async (req, res, next) => {
  try {
    const parsed = registerSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Email yoki parol talablarga mos emas" });
    const { email, password } = parsed.data;
    const passwordHash = await bcrypt.hash(password, 12);
    const result = await db.query(
      "INSERT INTO users(email, password_hash) VALUES($1, $2) RETURNING id, email, role, created_at",
      [email, passwordHash]
    );
    const user = result.rows[0];
    res.status(201).json({ user, token: makeToken(user), note: "Demo hisob yaratildi. Bu real pul hisobi emas." });
  } catch (err) {
    if (err.code === "23505") return res.status(409).json({ error: "Bu email ro'yxatdan o'tgan" });
    next(err);
  }
});

router.post("/login", async (req, res, next) => {
  try {
    const parsed = loginSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Kiritilgan ma'lumotlar noto'g'ri" });
    const { email, password, code } = parsed.data;
    const result = await db.query(
      "SELECT id, email, password_hash, role, totp_secret_encrypted, totp_enabled, created_at FROM users WHERE email=$1",
      [email]
    );
    const user = result.rows[0];
    const valid = user && await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: "Email yoki parol noto'g'ri" });

    if (user.totp_enabled) {
      if (!code || !user.totp_secret_encrypted) {
        return res.status(401).json({ error: "Ikki bosqichli tasdiqlash kodi kerak", requires2FA: true });
      }
      const secret = decryptSecret(user.totp_secret_encrypted);
      const verified = speakeasy.totp.verify({ secret, encoding: "base32", token: code, window: 1 });
      if (!verified) return res.status(401).json({ error: "2FA kodi noto'g'ri", requires2FA: true });
    }

    const publicUser = { id: user.id, email: user.email, role: user.role, created_at: user.created_at };
    res.json({ user: publicUser, token: makeToken(publicUser) });
  } catch (err) { next(err); }
});

router.get("/me", authRequired, async (req, res, next) => {
  try {
    const result = await db.query(
      "SELECT id, email, role, totp_enabled, created_at FROM users WHERE id=$1",
      [req.auth.sub]
    );
    if (!result.rows[0]) return res.status(404).json({ error: "Foydalanuvchi topilmadi" });
    res.json({ user: result.rows[0] });
  } catch (err) { next(err); }
});

router.post("/2fa/setup", authRequired, async (req, res, next) => {
  try {
    const result = await db.query("SELECT email, totp_enabled FROM users WHERE id=$1", [req.auth.sub]);
    const user = result.rows[0];
    if (!user) return res.status(404).json({ error: "Foydalanuvchi topilmadi" });
    if (user.totp_enabled) return res.status(409).json({ error: "2FA allaqachon yoqilgan" });

    const generated = speakeasy.generateSecret({ name: `CryptoPay (${user.email})`, length: 20 });
    await db.query("UPDATE users SET totp_secret_encrypted=$1 WHERE id=$2",
      [encryptSecret(generated.base32), req.auth.sub]);
    res.json({
      secret: generated.base32,
      otpauthUrl: generated.otpauth_url,
      warning: "Secretni hech kimga yubormang. Uni authenticator ilovasiga kiriting, keyin /2fa/enable orqali tasdiqlang."
    });
  } catch (err) { next(err); }
});

router.post("/2fa/enable", authRequired, async (req, res, next) => {
  try {
    const code = z.string().regex(/^\d{6}$/).safeParse(req.body.code);
    if (!code.success) return res.status(400).json({ error: "6 xonali kod kiriting" });
    const result = await db.query("SELECT totp_secret_encrypted FROM users WHERE id=$1", [req.auth.sub]);
    const encrypted = result.rows[0]?.totp_secret_encrypted;
    if (!encrypted) return res.status(400).json({ error: "Avval /2fa/setup bajaring" });
    const secret = decryptSecret(encrypted);
    const verified = speakeasy.totp.verify({ secret, encoding: "base32", token: code.data, window: 1 });
    if (!verified) return res.status(400).json({ error: "Kod tasdiqlanmadi" });
    await db.query("UPDATE users SET totp_enabled=TRUE WHERE id=$1", [req.auth.sub]);
    res.json({ ok: true, message: "2FA yoqildi" });
  } catch (err) { next(err); }
});

router.get("/admin/users", authRequired, adminRequired, async (req, res, next) => {
  try {
    const result = await db.query(
      "SELECT id, email, role, totp_enabled, created_at FROM users ORDER BY created_at DESC LIMIT 100"
    );
    res.json({ users: result.rows });
  } catch (err) { next(err); }
});

module.exports = { router, authRequired };
