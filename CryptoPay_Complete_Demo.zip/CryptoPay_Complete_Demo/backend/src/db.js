const { Pool } = require("pg");
const { databaseUrl, nodeEnv } = require("./config");

const pool = new Pool({
  connectionString: databaseUrl,
  ssl: nodeEnv === "production" ? { rejectUnauthorized: true } : false,
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000
});

pool.on("error", (err) => {
  console.error("PostgreSQL pool error:", err.message);
});

module.exports = {
  query: (text, params) => pool.query(text, params),
  pool
};
