# Tezkor API sinovlari

Ro'yxatdan o'tish:
```bash
curl -X POST http://localhost:4000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"demo@example.com","password":"StrongPassword123"}'
```

Kirish:
```bash
curl -X POST http://localhost:4000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"demo@example.com","password":"StrongPassword123"}'
```

Profil (TOKEN o'rniga login javobidagi token):
```bash
curl http://localhost:4000/api/auth/me -H "Authorization: Bearer TOKEN"
```
