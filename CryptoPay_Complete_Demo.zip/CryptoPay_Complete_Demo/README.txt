CryptoPay Complete Demo
Batafsil ko'rsatma: README_UZ.md
Frontend: frontend/
Backend: backend/
Database schema: database/schema.sql
Faqat demo; real mablag' yoki savdo yo'q.
