
# CryptoPay — yagona birlashtirilgan demo ilova

Bu ZIP ichida frontend, backend va ma'lumotlar bazasi sxemasi bitta loyihaga yig'ilgan.

## Ichida nimalar bor?
- Binance uslubidagi qorong'i boshqaruv paneli
- Bosh sahifa va demo ko'rsatkichlar
- Ommaviy Binance API orqali kripto narxlari (internet/API mavjud bo'lsa)
- Coin qidirish va saralash
- Demo savdo terminali, narx/miqdor hisoblash va brauzer ichidagi demo tarix
- Backend ro'yxatdan o'tish, login, profil
- Parol xeshlash, JWT, so'rovlarni cheklash
- TOTP ikki bosqichli himoya (2FA)
- Administrator roliga tayyor endpoint
- PWA manifest va service worker: HTTPS orqali joylangach, mos Android brauzerida “Install app / Add to Home screen” ko'rinishi mumkin

## Muhim: bu 100% tayyor real birja emas
Bu ishga tushadigan demo/MVP poydevori. Real savdo, depozit, pul yechish, custody/hamyon, private key, foydalanuvchi mablag'i yoki to'lov provayderi ulanmagan. Demo buyurtmalar birjaga yuborilmaydi. Binance API faqat ommaviy narx ma'lumotini olishga ishlatiladi.

Haqiqiy pul bilan xizmat ko'rsatishdan oldin O'zbekistondagi tegishli litsenziya/ruxsatlar va yuridik xulosa, KYC/AML, to'lov/custody hamkorlari, xavfsizlik arxitekturasi, audit, penetration test, monitoring, incident response va zaxira nusxalari talab etiladi. Bu ZIP ularning o'rnini bosmaydi.

## Kerakli dasturlar
- Node.js 20+
- PostgreSQL 14+
- Frontendni servis qilish uchun lokal HTTP server (masalan, VS Code Live Server) yoki hosting

## 1. Backendni sozlash
`backend` papkasida `.env.example` faylidan `.env` nusxa oling.
`DATABASE_URL` ni PostgreSQL ma'lumotlaringiz bilan almashtiring.

Kalitlar yaratish:
```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```
Birinchi natija `JWT_SECRET`, ikkinchisi `TOTP_ENCRYPTION_KEY` uchun. Maxfiy kalitlarni hech kimga yubormang.

Ma'lumotlar bazasini yarating va sxemani bajaring:
```bash
psql "postgresql://USER:PAROL@localhost:5432/cryptopay" -f sql/schema.sql
```
Yoki `backend/sql/schema.sql` faylini pgAdmin Query Tool'da ishga tushiring.

Backend:
```bash
cd backend
npm install
npm run dev
```
Tekshirish: `http://localhost:4000/health`

## 2. Frontendni ishga tushirish
`frontend/app.js` faylining boshidagi `API_BASE` ni backend manziliga moslang:
```js
const API_BASE = "http://localhost:4000";
```
`frontend` papkasini Live Server yoki boshqa HTTP server bilan oching. Brauzerda ilova ochiladi.

Agar telefonda sinasangiz, `localhost` telefonning o'zini anglatadi. Backend kompyuterda bo'lsa, kompyuterning lokal IP manzilini yozing va CORS sozlamasini ham moslang. Internetda joylashda HTTPS domenlardan foydalaning.

## 3. Demo test
1. Hisob yaratish: email va kamida 12 belgili parol.
2. Hisobga kirib profilni ko'ring.
3. 2FA sozlashni sinang.
4. Bozor bo'limida narxlarni ko'ring.
5. Savdo terminalida miqdor kiriting va demo hisob-kitob qiling.

## 4. Android ilova sifatida
Bu ZIP APK emas. Frontend PWA sifatida tayyorlangan. HTTPS hostingga joylangach, Android Chrome menyusida “Install app” yoki “Add to Home screen” chiqishi mumkin. APK/AAB kerak bo'lsa, keyin alohida Android wrapper va signing jarayoni kerak bo'ladi.

## 5. Hozircha mavjud bo'lmagan ishlab chiqarish funksiyalari
- Email tasdiqlash va parolni tiklash
- Refresh token/session va to'liq production cookie strategiyasi
- KYC/AML provayderi va risk tekshiruvlari
- Real balans, order matching yoki exchange broker integratsiyasi
- Depozit/withdrawal va to'lov provayderi
- Wallet custody va kalitlarni boshqarish
- Audit log, monitoring, backup/restore va incident response
- Mustaqil xavfsizlik auditi va yuridik ruxsatlar

Bularni xavfsiz va qonuniy talablar asosida keyingi alohida bosqichlarda loyihalash kerak.
