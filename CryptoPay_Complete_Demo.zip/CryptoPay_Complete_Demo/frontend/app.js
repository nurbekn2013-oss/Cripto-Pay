
// Backend manzili: lokal kompyuterda http://localhost:4000; serverga joylaganda HTTPS API domeni.
const API_BASE = "http://localhost:4000";
const TOKEN_KEY = "cryptopay_demo_token";
const symbols = ["BTCUSDT","ETHUSDT","BNBUSDT","SOLUSDT","ADAUSDT","XRPUSDT","DOGEUSDT","TRXUSDT"];
const labels = {BTCUSDT:["Bitcoin","BTC"],ETHUSDT:["Ethereum","ETH"],BNBUSDT:["BNB","BNB"],SOLUSDT:["Solana","SOL"],ADAUSDT:["Cardano","ADA"],XRPUSDT:["XRP","XRP"],DOGEUSDT:["Dogecoin","DOGE"],TRXUSDT:["TRON","TRX"]};
let tickers = {}, side = "buy", authMode = "login";
const $ = id => document.getElementById(id);
const token = () => sessionStorage.getItem(TOKEN_KEY);
async function api(path, options={}) {
  const headers={"Content-Type":"application/json",...(options.headers||{})};
  if(token()) headers.Authorization=`Bearer ${token()}`;
  let r; try { r=await fetch(API_BASE+path,{...options,headers}); } catch { throw Error("Backendga ulanib bo‘lmadi. API manzilini va serverni tekshiring."); }
  const data=await r.json().catch(()=>({}));
  if(!r.ok){const e=Error(data.error||`Server xatosi ${r.status}`);e.data=data;throw e;} return data;
}
function message(id,txt,ok=false){$(id).textContent=txt;$(id).style.color=ok?"#55d6a0":"#f18b8b";}
function showPage(name){
 document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id==="page-"+name));
 document.querySelectorAll(".nav").forEach(b=>b.classList.toggle("active",b.dataset.page===name));
 $("sidebar").classList.remove("open");
}
document.querySelectorAll(".nav").forEach(b=>b.onclick=()=>showPage(b.dataset.page));
document.querySelectorAll("[data-goto]").forEach(b=>b.onclick=()=>showPage(b.dataset.goto));
$("menuBtn").onclick=()=>$("sidebar").classList.toggle("open");
function fmt(n){return Number(n).toLocaleString("en-US",{maximumFractionDigits:8});}
async function loadMarkets(){
 try{
  const r=await fetch("https://api.binance.com/api/v3/ticker/24hr"); if(!r.ok)throw Error("API");
  const arr=await r.json(); tickers={}; arr.forEach(t=>{if(symbols.includes(t.symbol))tickers[t.symbol]=t;});
  $("apiState").textContent="Ommaviy bozor API faol";
  renderMarkets(); updateTrade(); updateHome();
 }catch{$("marketStatus").textContent="Bozor API hozir mavjud emas. Internet yoki hududiy cheklovni tekshiring."; $("apiState").textContent="Bozor API ulanmagan";}
}
function renderMarkets(){
 const q=$("marketSearch").value.toLowerCase(), sort=$("marketSort").value;
 let rows=symbols.filter(s=>(labels[s][0]+labels[s][1]).toLowerCase().includes(q));
 if(sort==="price")rows.sort((a,b)=>Number(tickers[b]?.lastPrice||0)-Number(tickers[a]?.lastPrice||0));
 if(sort==="change")rows.sort((a,b)=>Number(tickers[b]?.priceChangePercent||0)-Number(tickers[a]?.priceChangePercent||0));
 $("marketRows").innerHTML=rows.map(s=>{const t=tickers[s],change=Number(t?.priceChangePercent||0);return `<tr><td><span class="coin">${labels[s][0]} <small>${labels[s][1]}</small></span></td><td>${t?fmt(t.lastPrice):"—"}</td><td class="${change>=0?"positive":"negative"}">${t?(change>=0?"+":"")+change.toFixed(2)+"%":"—"}</td><td><button class="outline" data-pair="${s}">Savdo</button></td></tr>`}).join("")||'<tr><td colspan="4">Coin topilmadi</td></tr>';
 document.querySelectorAll("[data-pair]").forEach(b=>b.onclick=()=>{$("tradeSelect").value=b.dataset.pair;updateTrade();showPage("trade");});
}
function updateHome(){
 for(const [s,id] of [["BTCUSDT","homeBtc"],["ETHUSDT","homeEth"]])if(tickers[s])$(id).textContent="$"+fmt(tickers[s].lastPrice);
 if(tickers.BTCUSDT){const n=Number(tickers.BTCUSDT.priceChangePercent);$("homeBtcChange").textContent=(n>=0?"+":"")+n.toFixed(2)+"% / 24 soat";$("homeBtcChange").className=n>=0?"positive":"negative";}
}
function updateTrade(){
 const s=$("tradeSelect").value,t=tickers[s],pair=s.replace("USDT"," / USDT");$("tradePair").textContent=pair;
 $("tradePrice").textContent=t?"$"+fmt(t.lastPrice)+"  "+Number(t.priceChangePercent).toFixed(2)+"%":"Narx mavjud emas";
 $("asks").textContent=t?"$"+fmt(Number(t.lastPrice)*1.0002):"—";$("bids").textContent=t?"$"+fmt(Number(t.lastPrice)*.9998):"—";calcEstimate();
}
function calcEstimate(){const s=$("tradeSelect").value,t=tickers[s],p=$("orderType").value==="limit"?Number($("limitPrice").value):Number(t?.lastPrice||0),q=Number($("quantity").value);$("estimate").textContent=fmt(p*q)+" USDT";}
$("marketSearch").oninput=renderMarkets;$("marketSort").onchange=renderMarkets;$("tradeSelect").onchange=updateTrade;$("quantity").oninput=calcEstimate;$("limitPrice").oninput=calcEstimate;
$("orderType").onchange=()=>{$("limitPrice").disabled=$("orderType").value!=="limit";calcEstimate();};
document.querySelectorAll("[data-side]").forEach(b=>b.onclick=()=>{side=b.dataset.side;document.querySelectorAll("[data-side]").forEach(x=>x.classList.toggle("active",x===b));$("placeOrder").textContent=side==="buy"?"Demo sotib olishni hisoblash":"Demo sotishni hisoblash";});
$("placeOrder").onclick=()=>{
 const s=$("tradeSelect").value,t=tickers[s],q=Number($("quantity").value),p=$("orderType").value==="limit"?Number($("limitPrice").value):Number(t?.lastPrice||0);
 if(!(q>0&&p>0)){message("orderMessage","To‘g‘ri narx va miqdor kiriting.");return;}
 const row=document.createElement("div");row.className="historyrow";row.textContent=`${new Date().toLocaleString("uz-UZ")} · DEMO ${side.toUpperCase()} · ${s} · ${q} coin · ${fmt(q*p)} USDT`;
 const hist=$("orderHistory");if(hist.textContent.includes("Hozircha"))hist.textContent="";hist.prepend(row);
 message("orderMessage","Hisoblandi. Buyurtma birjaga yuborilmadi; balans o‘zgarmadi.",true);
};
document.querySelectorAll("[data-auth]").forEach(b=>b.onclick=()=>{authMode=b.dataset.auth;document.querySelectorAll("[data-auth]").forEach(x=>x.classList.toggle("active",x===b));$("authSubmit").textContent=authMode==="login"?"Kirish":"Hisob yaratish";$("twofaField").classList.add("hidden");});
$("authForm").onsubmit=async e=>{
 e.preventDefault();$("authSubmit").disabled=true;
 try{const body={email:$("email").value.trim(),password:$("password").value};if(authMode==="login"&&$("twofaCode").value)body.code=$("twofaCode").value;
 const d=await api("/api/auth/"+(authMode==="login"?"login":"register"),{method:"POST",body:JSON.stringify(body)});
 sessionStorage.setItem(TOKEN_KEY,d.token);await loadProfile();
 }catch(err){message("authMessage",err.message);if(err.data?.requires2FA)$("twofaField").classList.remove("hidden");}
 finally{$("authSubmit").disabled=false;}
};
async function loadProfile(){
 const d=await api("/api/auth/me"),u=d.user;
 $("authPanel").classList.add("hidden");$("profilePanel").classList.remove("hidden");
 $("pEmail").textContent=u.email;$("pRole").textContent=u.role;$("p2fa").textContent=u.totp_enabled?"Yoqilgan":"O‘chirilgan";$("pDate").textContent=new Date(u.created_at).toLocaleDateString("uz-UZ");
 $("setup2fa").classList.toggle("hidden",u.totp_enabled);$("twofaSetup").classList.add("hidden");
}
$("logout").onclick=()=>{sessionStorage.removeItem(TOKEN_KEY);$("profilePanel").classList.add("hidden");$("authPanel").classList.remove("hidden");};
$("setup2fa").onclick=async()=>{try{const d=await api("/api/auth/2fa/setup",{method:"POST",body:"{}"});$("secret").textContent=d.secret;$("twofaSetup").classList.remove("hidden");message("profileMessage","Kalitni authenticator ilovasiga qo‘shing.",true);}catch(e){message("profileMessage",e.message);}};
$("enable2fa").onclick=async()=>{try{await api("/api/auth/2fa/enable",{method:"POST",body:JSON.stringify({code:$("confirmCode").value})});message("profileMessage","2FA yoqildi.",true);await loadProfile();}catch(e){message("profileMessage",e.message);}};
(async()=>{if("serviceWorker" in navigator)navigator.serviceWorker.register("./sw.js").catch(()=>{});loadMarkets();setInterval(loadMarkets,30000);if(token())try{await loadProfile();}catch{sessionStorage.removeItem(TOKEN_KEY);}})();
